package com.example.personas

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import android.widget.EditText
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONArray
import org.json.JSONObject

class Buscar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_buscar)

        val vcodigo = findViewById<EditText>(R.id.txt_buscar_codigo)
        val vnombres = findViewById<EditText>(R.id.txt_buscar_nombres)
        val vapellidos = findViewById<EditText>(R.id.txt_buscar_apellidos)
        val vdireccion = findViewById<EditText>(R.id.txt_buscar_direccion)
        val vtelefono = findViewById<EditText>(R.id.txt_buscar_telefono)
        val btnActualizar = findViewById<Button>(R.id.btn_buscar_modificar)
        val btnBuscar = findViewById<Button>(R.id.btn_buscar_buscar)

        val btn: Button = findViewById(R.id.btn_buscar_menu)
        btn.setOnClickListener{
            val intent: Intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }

        btnBuscar.setOnClickListener{
            val requestQueue = Volley.newRequestQueue(this)
            var url ="https://efpem-usac-lesly.000webhostapp.com/Android/buscar.php?"
            url += "codigo="+vcodigo.getText().toString()

            val stringRequest = StringRequest(Request.Method.GET, url,
                Response.Listener { response ->
                val jsonArray = JSONArray(response)
                var objetoJson = JSONObject(jsonArray.getString(0))
                vnombres.setText(objetoJson.getString("nombres"))
                vapellidos.setText(objetoJson.getString("apellidos"))
                vdireccion.setText(objetoJson.getString("direccion"))
                vtelefono.setText(objetoJson.getString("telefono"))
                },
                Response.ErrorListener { error ->
                    Toast.makeText(this,"Error en conexion",Toast.LENGTH_SHORT).show()
                })
            requestQueue.add(stringRequest)
        }

        btnActualizar.setOnClickListener {
            val requestQueue = Volley.newRequestQueue(this)
            var url= "https://efpem-usac-lesly.000webhostapp.com/Android/actualizar.php?"
            url += "codigo=" + vcodigo.getText().toString()
            url += "&nombres=" + vnombres.getText().toString()
            url += "&apellidos=" + vapellidos.getText().toString()
            url += "&direccion=" + vdireccion.getText().toString()
            url += "&telefono=" + vtelefono.getText().toString()

            val stringRequest = StringRequest(Request.Method.GET, url,
                Response.Listener<String> { response ->
                    val jsonArray = JSONArray(response)
                    var objetoJson = JSONObject(jsonArray.getString(0))
                    Toast.makeText(this, "Docente modificado", Toast.LENGTH_SHORT).show()
                },
                Response.ErrorListener { error ->
                    Toast.makeText(this,"Error al modificar",Toast.LENGTH_SHORT).show()
                })
            requestQueue.add(stringRequest)
        }
    }
}