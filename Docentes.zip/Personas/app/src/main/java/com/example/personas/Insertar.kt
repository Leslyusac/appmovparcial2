 package com.example.personas

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONArray
import org.json.JSONObject

 class Insertar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_insertar)

        val vcodigo = findViewById<EditText>(R.id.txt_insertar_codigo)
        val vnombre = findViewById<EditText>(R.id.txt_insertar_nombres)
        val vapellido = findViewById<EditText>(R.id.txt_insertar_apellidos)
        val vdireccion = findViewById<EditText>(R.id.txt_insertar_direccion)
        val vtelefono = findViewById<EditText>(R.id.txt_insertar_telefono)
        val btnGuardar = findViewById<Button>(R.id.btn_insertar_insertar)

        val btn: Button = findViewById(R.id.btn_insertar_menu)
        btn.setOnClickListener{
            val intent: Intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }

        btnGuardar.setOnClickListener {
            val requestQueue = Volley.newRequestQueue(this)
           var url ="https://efpem-usac-lesly.000webhostapp.com/Android/insertar.php?"
            url += "codigo=" + vcodigo.getText().toString()
            url += "&nombres=" + vnombre.getText().toString()
            url += "&apellidos=" + vapellido.getText().toString()
            url += "&direccion=" + vdireccion.getText().toString()
            url += "&telefono=" + vtelefono.getText().toString()
            val stringRequest = StringRequest(Request.Method.GET, url,
                { response ->
                    val jsonArray = JSONArray(response)
                    val objeto = JSONObject(jsonArray.getString(0))
                    Log.d("Datos", objeto.toString())
                    Log.d("Codigo: ", objeto.getString("codigo"))
                    Log.d("Nombres: ", objeto.getString("nombres"))
                    Log.d("Apellidos: ", objeto.getString("apellidos"))
                    Log.d("Direccion: ", objeto.getString("direccion"))
                    Log.d("Telefono: ", objeto.getString("telefono"))
                    Toast.makeText(this, "Docente registrado", Toast.LENGTH_SHORT).show()
                },
                { error ->
                    Toast.makeText(this, "Error en registro", Toast.LENGTH_SHORT).show()
                })
            requestQueue.add(stringRequest)
        }
    }
}





